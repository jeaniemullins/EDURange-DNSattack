#!/usr/bin/python

import os
import sys

import random
import socket
import httplib

import copy

from dnslib import *

import cs596

QUESTION_HOSTNAME = "www.good.com"

LAB_NUM = 5
PROB_NUM = 1
TCP_PORT = 1000 * LAB_NUM + PROB_NUM
UDP_PORT = 5300 + PROB_NUM

#student_ips = ["10.1.247.1"]

while True:

  ip_range = cs596.student_IPs
  random.shuffle(ip_range)

  for student_ip in ip_range:
    print ""
    q1 = DNSRecord(q=DNSQuestion(QUESTION_HOSTNAME))
    print "Sending to", student_ip, "query = ", q1 
    print "Packed query = [", q1.pack(), "]"

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(4)
    try:
      sock.sendto(q1.pack(), (student_ip, UDP_PORT))
    except:
      continue

    try:
      data, addr = sock.recvfrom(1024)
    except:
      print "Didn't get a response from", student_ip
      continue
    try:
      response = DNSRecord.parse(data)
    except:
      print "Couldn't parse response from", student_ip
      continue
    print "Received reponse = ", response
    giveup = False
    for rr in response.rr:
      if giveup:
        break
      if rr.rname == DNSLabel(QUESTION_HOSTNAME):
        print "\tFound\tname = ", rr.rname, "\tdata = ", rr.rdata
        ip = str(rr.rdata)
        theflag = cs596.flag(LAB_NUM, PROB_NUM, ip)
        try:
          s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
          s.settimeout(2)
          print "Trying to connect to", ip, "on port", TCP_PORT
          s.connect((ip,TCP_PORT))
          s.sendall("FLAG %s\r\n" % theflag)
          s.close()
        except:
          print "Failed to send flag to", ip
          giveup = True


