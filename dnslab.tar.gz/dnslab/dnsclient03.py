#!/usr/bin/python

import os
import sys
import time

import random

import socket
import httplib

from dnslib import *

VICTIM_HOSTNAME = "www.good.com"

LAB_NUM = 5
PROB_NUM = 3
TCP_PORT = 1000 * LAB_NUM + PROB_NUM
UDP_PORT = 5300 + PROB_NUM

REMOTE_IP = "192.168.14.150"

UDP_IP = sys.argv[1]

usock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
usock.bind((UDP_IP,UDP_PORT))
print "Listening on", UDP_IP, ":", UDP_PORT

while True:
  data, addr = usock.recvfrom(1024)
  remote_ip, remote_port = addr
  if remote_port != UDP_PORT or remote_ip != REMOTE_IP:
    continue

  # Pretend that we look at the DNS query ID
  # If we did we'd throw out all but 1 / 2**16 answers
  # Here we'll be a little more forgiving
  if random.randint(1,400) != 1:
    continue

  try:
    response = DNSRecord.parse(data)
    print "Received reponse = ", response

    # If so, then pretend our DNS cache has been poisoned
    # Wait a little while, then try to connect to the victim hostname
    # And send it the flag
    for rr in response.rr:
      if rr.rname == DNSLabel(VICTIM_HOSTNAME):
        print "\tFound\tname = ", rr.rname, "\tdata = ", rr.rdata
        ip = rr.rdata
        theflag = cs596.flag(LAB_NUM, PROB_NUM, ip)
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(5)
        s.connect((ip,TCP_PORT))
        s.sendall("FLAG %s\r\n" % theflag)
        s.close()
        print "Sent the flag to", ip

  except Exception:
    print "Failed to handle response from", remote_ip
