#!/usr/bin/python

import os
import sys

import socket
import httplib

from dnslib import *

QUESTION_HOSTNAME = "www.one.com"
UDP_PORT = 1053

student_ips = ["127.0.0.1"]

for student_ip in student_ips:
  query = DNSRecord(q=DNSQuestion(QUESTION_HOSTNAME))
  print "query = ", query

  sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
  sock.sendto(query.pack(), (student_ip, UDP_PORT))

  data, addr = sock.recvfrom(1024)
  response = DNSRecord.parse(data)
  print "Received reponse = ", response
  for rr in response.rr:
    if rr.rname == DNSLabel(QUESTION_HOSTNAME):
      print "\tFound\tname = ", rr.rname, "\tdata = ", rr.rdata
