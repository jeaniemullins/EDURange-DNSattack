##################################################################
#
# Utility functions for CS 596 Network Security lab exercises
#
##################################################################

from Crypto.Hash import HMAC
from Crypto.Hash import SHA256
#from Crypto.Protocol import PBKDF2

FLAG_LEN = 16

random_chars = "alkja;lsjfglkasdjflkjs995ljasdjf"
course_dept = "CS"
course_num = "410510"
term = "Spring"
year = "2015"

salt_phrase = " ".join([course_dept, course_num, term, year])
salt = SHA256.new(salt_phrase).hexdigest()
#secret_key = PBKDF2(random_chars, salt)
secret_key = SHA256.new(random_chars + salt).digest()


net_prefix = "192.168.14."
student_IPs = map(lambda x: net_prefix+str(x), range(110,124))

def flag(lab_num, challenge_num, student=None):
  global secret_key
  h = HMAC.new(secret_key)
  h.update("%s:%s:%s" % (str(lab_num), str(challenge_num), str(student)))
  return h.hexdigest()[:FLAG_LEN]


