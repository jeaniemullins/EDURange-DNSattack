#!/usr/bin/python

import os
import sys

import socket
import httplib

from dnslib import *

QUESTION_HOSTNAME = "www.yahoo.com"
UDP_PORT = 53

student_ips = ["10.1.247.1"]

for student_ip in student_ips:
  query = DNSRecord(q=DNSQuestion(QUESTION_HOSTNAME))
  print "query = ", query

  sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
  sock.sendto(query.pack(), (student_ip, UDP_PORT))

  data, addr = sock.recvfrom(1024)
  response = DNSRecord.parse(data)
  print "Received reponse = ", response
  for rr in response.rr:
    if rr.rname == DNSLabel(QUESTION_HOSTNAME):
      print "\tFound\tname = ", rr.rname, "\tdata = ", rr.rdata
      h = httplib.HTTPConnection(str(rr.rdata))
      h.connect()
      h.request("GET", "/index.html")
      r = h.getresponse()
      print "\tGot response = ", r
      data = r.read(1024)
      print "\tGot data = ", data
