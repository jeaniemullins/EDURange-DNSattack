#!/usr/bin/python

import os
import sys

import socket

from dnslib import *

UDP_IP = sys.argv[1]
UDP_PORT = 1053


usock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
usock.bind((UDP_IP,UDP_PORT))

dns_names = {}
dns_names[DNSLabel("www.one.com")] = "1.1.1.1"
dns_names[DNSLabel("www.two.com")] = "2.2.2.2"
dns_names[DNSLabel("www.three.com")] = "3.3.3.3"
dns_names[DNSLabel("www.four.com")] = "4.4.4.4"

while True:
  data, addr = usock.recvfrom(1024)
  remote_ip, remote_port = addr
  print "Got a packet from", remote_ip
  
  try:
    query = DNSRecord.parse(data)
    print "Got query = ", query
    response = None
    for q in query.questions:
      print "\tFound question", q.qname, q.qclass
      if q.qname in dns_names.keys():
        print "\tWe know this answer"
        ip = dns_names[q.qname]
        print "\tAnswer is", ip
        if response is None:
          response = query.reply(data=ip)
        else:
          response.add_answer(RR(q.qname,QTYPE.A,rdata=A(ip)))
    print "Response = ", response
    print "Sending response..."
    usock.sendto(response.pack(), addr)
  except:
    print "Failed to handle request from", remote_ip
